-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.11 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table ros.bo_menu
CREATE TABLE IF NOT EXISTS `bo_menu` (
  `bm_id` int(3) NOT NULL AUTO_INCREMENT,
  `bm_order` int(3) DEFAULT NULL,
  `bm_parent_id` int(3) DEFAULT '0',
  `bm_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_link` text COLLATE utf8_unicode_ci,
  `bm_icon` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bm_type` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '0',
  `bm_status` enum('y','n') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'y',
  PRIMARY KEY (`bm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table ros.bo_menu: ~0 rows (approximately)
DELETE FROM `bo_menu`;
/*!40000 ALTER TABLE `bo_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `bo_menu` ENABLE KEYS */;


-- Dumping structure for table ros.bo_module
CREATE TABLE IF NOT EXISTS `bo_module` (
  `bmd_id` int(12) NOT NULL AUTO_INCREMENT,
  `bmd_order` int(12) DEFAULT NULL,
  `bmd_name` varchar(128) DEFAULT NULL,
  `bmd_mod_name` varchar(128) DEFAULT NULL,
  `bmd_desc` text,
  `bmd_status` enum('y','n') DEFAULT NULL,
  PRIMARY KEY (`bmd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.bo_module: ~0 rows (approximately)
DELETE FROM `bo_module`;
/*!40000 ALTER TABLE `bo_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `bo_module` ENABLE KEYS */;


-- Dumping structure for table ros.bo_users
CREATE TABLE IF NOT EXISTS `bo_users` (
  `bu_id` int(11) NOT NULL AUTO_INCREMENT,
  `mwd_id` int(3) DEFAULT NULL,
  `bu_real_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bu_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bu_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bu_passwd` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bu_salt` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bu_init` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bu_pic` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bu_level` int(2) DEFAULT NULL,
  `bu_status` enum('y','n') COLLATE utf8_unicode_ci DEFAULT 'y',
  `bu_create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`bu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table ros.bo_users: ~0 rows (approximately)
DELETE FROM `bo_users`;
/*!40000 ALTER TABLE `bo_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `bo_users` ENABLE KEYS */;


-- Dumping structure for table ros.bo_user_level
CREATE TABLE IF NOT EXISTS `bo_user_level` (
  `bul_id` int(2) NOT NULL AUTO_INCREMENT,
  `bul_order` int(2) DEFAULT NULL,
  `bul_level_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bul_menu_role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bul_module_role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bul_status` enum('y','n') COLLATE utf8_unicode_ci DEFAULT 'y',
  PRIMARY KEY (`bul_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table ros.bo_user_level: ~0 rows (approximately)
DELETE FROM `bo_user_level`;
/*!40000 ALTER TABLE `bo_user_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `bo_user_level` ENABLE KEYS */;


-- Dumping structure for table ros.ros_brands
CREATE TABLE IF NOT EXISTS `ros_brands` (
  `rb_id` int(3) NOT NULL AUTO_INCREMENT,
  `rb_name` varchar(100) DEFAULT NULL,
  `rb_image` varchar(255) DEFAULT NULL,
  `rb_link` varchar(255) DEFAULT NULL,
  `rb_status` enum('y','n') DEFAULT 'y',
  PRIMARY KEY (`rb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.ros_brands: ~0 rows (approximately)
DELETE FROM `ros_brands`;
/*!40000 ALTER TABLE `ros_brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_brands` ENABLE KEYS */;


-- Dumping structure for table ros.ros_cat_product
CREATE TABLE IF NOT EXISTS `ros_cat_product` (
  `cp_id` int(3) NOT NULL AUTO_INCREMENT,
  `cp_name` varchar(100) DEFAULT NULL,
  `cp_slug` varchar(100) DEFAULT NULL,
  `cp_status` enum('y','n') DEFAULT 'y',
  PRIMARY KEY (`cp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.ros_cat_product: ~0 rows (approximately)
DELETE FROM `ros_cat_product`;
/*!40000 ALTER TABLE `ros_cat_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_cat_product` ENABLE KEYS */;


-- Dumping structure for table ros.ros_customer
CREATE TABLE IF NOT EXISTS `ros_customer` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `cus_fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cus_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cus_pass` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cus_phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `cus_address` text COLLATE utf8_unicode_ci NOT NULL,
  `cus_city` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cus_province` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cus_zip` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cus_reg_date` date DEFAULT NULL,
  `cus_active_date` date DEFAULT NULL,
  `cus_active` enum('y','n','none') COLLATE utf8_unicode_ci DEFAULT 'none',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table ros.ros_customer: ~0 rows (approximately)
DELETE FROM `ros_customer`;
/*!40000 ALTER TABLE `ros_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_customer` ENABLE KEYS */;


-- Dumping structure for table ros.ros_product
CREATE TABLE IF NOT EXISTS `ros_product` (
  `p_id` int(3) NOT NULL AUTO_INCREMENT,
  `p_cat` int(3) DEFAULT NULL,
  `p_img` varchar(255) DEFAULT NULL,
  `p_name` varchar(100) DEFAULT NULL,
  `p_slug` varchar(100) DEFAULT NULL,
  `p_desc` text,
  `p_price_before` int(100) DEFAULT NULL,
  `p_price_after` int(100) DEFAULT NULL,
  `p_status` int(100) DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.ros_product: ~0 rows (approximately)
DELETE FROM `ros_product`;
/*!40000 ALTER TABLE `ros_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_product` ENABLE KEYS */;


-- Dumping structure for table ros.ros_shipping_cost
CREATE TABLE IF NOT EXISTS `ros_shipping_cost` (
  `rsc_id` int(3) NOT NULL AUTO_INCREMENT,
  `rsc_to` varchar(100) DEFAULT NULL,
  `rsc_cos` varchar(100) DEFAULT NULL,
  `rsc_status` enum('y','n') DEFAULT NULL,
  PRIMARY KEY (`rsc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.ros_shipping_cost: ~0 rows (approximately)
DELETE FROM `ros_shipping_cost`;
/*!40000 ALTER TABLE `ros_shipping_cost` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_shipping_cost` ENABLE KEYS */;


-- Dumping structure for table ros.ros_slide
CREATE TABLE IF NOT EXISTS `ros_slide` (
  `s_id` int(3) NOT NULL AUTO_INCREMENT,
  `s_title` varchar(100) DEFAULT NULL,
  `s_desc` text,
  `s_img` varchar(255) DEFAULT NULL,
  `s_status` enum('y','n') DEFAULT 'y',
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.ros_slide: ~0 rows (approximately)
DELETE FROM `ros_slide`;
/*!40000 ALTER TABLE `ros_slide` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_slide` ENABLE KEYS */;


-- Dumping structure for table ros.ros_static
CREATE TABLE IF NOT EXISTS `ros_static` (
  `rs_id` int(3) NOT NULL AUTO_INCREMENT,
  `rs_name` varchar(100) DEFAULT NULL,
  `rs_desc` text,
  `rs_status` enum('y','n') DEFAULT NULL,
  PRIMARY KEY (`rs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.ros_static: ~0 rows (approximately)
DELETE FROM `ros_static`;
/*!40000 ALTER TABLE `ros_static` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_static` ENABLE KEYS */;


-- Dumping structure for table ros.ros_trx
CREATE TABLE IF NOT EXISTS `ros_trx` (
  `rt_id` int(10) NOT NULL AUTO_INCREMENT,
  `rt_code` varchar(20) DEFAULT NULL,
  `rt_cus` int(3) DEFAULT NULL,
  `rt_prod` int(3) DEFAULT NULL,
  `rt_price` int(10) DEFAULT NULL,
  `rt_amount` int(3) DEFAULT NULL,
  `rt_total_price` int(10) DEFAULT NULL,
  `rt_trx_date` datetime DEFAULT NULL,
  `rt_status` enum('y','n') DEFAULT NULL,
  PRIMARY KEY (`rt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ros.ros_trx: ~0 rows (approximately)
DELETE FROM `ros_trx`;
/*!40000 ALTER TABLE `ros_trx` DISABLE KEYS */;
/*!40000 ALTER TABLE `ros_trx` ENABLE KEYS */;


-- Dumping structure for table ros.users
CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(3) NOT NULL AUTO_INCREMENT,
  `realname` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `u_note` text NOT NULL,
  `u_level` enum('0','1','2','3','4') NOT NULL,
  `u_status` enum('y','n') NOT NULL,
  `u_date` date NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table ros.users: ~1 rows (approximately)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`uid`, `realname`, `email`, `username`, `password`, `u_note`, `u_level`, `u_status`, `u_date`) VALUES
	(1, 'Super Admin', 'hello@Lingkar9.com', 'super', '0192023a7bbd73250516f069df18b500', 'pass : admin123', '0', 'y', '2014-06-22');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
